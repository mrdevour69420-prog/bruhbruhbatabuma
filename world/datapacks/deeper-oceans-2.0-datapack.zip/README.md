Hello! If you're reading this, I assume you want to edit the ocean depth.

Luckily, that's super easy! Open the following file:
`data/deeper_oceans/worldgen/density_function/depth_multiplier.json`
...and you'll see a file with a single number for the depth multiplier! That controls how deep the oceans are relative to vanilla. Make your changes, save, and load the datapack!