loot spawn ~ ~ ~ loot minecraft:blocks/stone_button
data modify entity @e[type=item,tag=!newItem,distance=..3,nbt={Age:0s},limit=1] Item set from entity @s data.Inventory[0]
tag @e[type=item,tag=!newItem,distance=..3,nbt={Age:0s}] add newItem
data remove entity @s data.Inventory[0]
execute if data entity @s data.Inventory[0] run function conures:graves/drop_next_item