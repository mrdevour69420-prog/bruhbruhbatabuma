execute on passengers if entity @s[type=marker,tag=grave] if data entity @s data.Inventory[0] run function conures:graves/drop_next_item
tag @e[tag=newItem] remove newItem
execute if score @s xp matches 1.. run summon experience_orb ~ ~ ~ {Tags:["newXP"]}
execute store result entity @e[tag=newXP,limit=1] Value short 1 run scoreboard players get @s xp
tag @e[tag=newXP] remove newXP
execute on passengers run kill @s[tag=grave]
kill @s[tag=grave]