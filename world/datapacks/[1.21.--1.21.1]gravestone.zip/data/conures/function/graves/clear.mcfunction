tellraw @s "Deleting all graves in loaded chunk region..."
execute as @e[type=interaction,tag=grave] at @s run function conures:graves/empty