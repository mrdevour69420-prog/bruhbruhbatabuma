execute unless entity @s[nbt={Health:0f}] run return 0
execute unless predicate conures:graves/within_world_bounds run return 0
tag @e[type=item,distance=..3,nbt={Age:0s}] add droppedItem
tag @e[type=experience_orb,distance=..3,nbt={Age:0s}] add droppedXP
execute unless entity @e[tag=droppedItem] unless entity @e[tag=droppedXP] run return 0

summon interaction ~ ~ ~ {width:.7f,height:1.2f,response:true,Tags:["grave","newGraveEntity"]}
summon marker ~ ~ ~ {data:{Inventory:[]},Tags:["grave","newGraveInventory"]}
summon block_display ~ ~ ~ {block_state:{Name:"minecraft:polished_basalt",Properties:{axis:"z"}},transformation:{translation:[-.35f,0f,-.125f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[.7f,1.2f,.25f]},Tags:["grave","newGraveStone"]}
tag @s add graveDropping
summon text_display ~ ~ ~ {text:'["",{"selector":"@p[tag=graveDropping]"},{"text":"\'s Grave\\nClick to Empty"}]',transformation:{translation:[0f,1.5f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[.5f,.5f,0f]},billboard:"vertical",Tags:["grave","newGraveText"]}
tag @s remove graveDropping

execute as @e[tag=droppedItem] run data modify entity @e[tag=newGraveInventory,limit=1] data.Inventory append from entity @s Item
kill @e[tag=droppedItem]
scoreboard players set @e[tag=newGraveEntity] xp 0
execute as @e[tag=droppedXP] store result score @s xp run data get entity @s Value
scoreboard players operation @e[tag=newGraveEntity] xp += @e[tag=droppedXP] xp
kill @e[tag=droppedXP]
data modify entity @e[tag=newGraveStone,limit=1] Rotation[0] set from entity @s Rotation[0]

ride @e[tag=newGraveInventory,limit=1] mount @e[tag=newGraveEntity,limit=1]
ride @e[tag=newGraveStone,limit=1] mount @e[tag=newGraveEntity,limit=1]
ride @e[tag=newGraveText,limit=1] mount @e[tag=newGraveEntity,limit=1]

tag @e[tag=newGraveEntity] remove newGraveEntity
tag @e[tag=newGraveInventory] remove newGraveInventory
tag @e[tag=newGraveStone] remove newGraveStone
tag @e[tag=newGraveText] remove newGraveText