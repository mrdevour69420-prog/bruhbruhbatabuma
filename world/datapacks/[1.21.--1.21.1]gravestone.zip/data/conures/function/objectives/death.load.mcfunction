scoreboard objectives add death deathCount
scoreboard players reset @e death