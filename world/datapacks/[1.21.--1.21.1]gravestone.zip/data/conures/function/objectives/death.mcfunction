scoreboard players reset @s death
function #conures:objectives/death