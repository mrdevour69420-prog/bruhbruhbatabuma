#> armorstandarms:app/setup
# Called on load

# Initiate all scoreboard objectives
function armorstandarms:app/scoreboard/add

# Print the image
function armorstandarms:config/image

advancement revoke @a only armorstandarms:right_click

scoreboard players set &show_arms riding_cast_temp 0

scoreboard players set &check_show_arms riding_cast_temp 1